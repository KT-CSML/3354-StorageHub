
public class Server {
	public static String[][] USER_LOGINS = {{"khiem@gmail.com","123456"},
											{"kevin@gmail.com","123456"}};
	public boolean isValidLogin(String username, String password)
	{
		for(int i = 0; i < USER_LOGINS.length ;i++)
		{
			if (USER_LOGINS[i][0].equals(username)
					&& USER_LOGINS[i][1].equals(password))
				return true;
		}
		return false;
	}
}
