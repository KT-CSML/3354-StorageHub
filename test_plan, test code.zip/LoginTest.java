import static org.junit.Assert.assertEquals;


import org.junit.jupiter.api.Test;
//All tests passed
class LoginTest {

	@Test
	void validLogin() {
		Server s = new Server();
		boolean isValid = s.isValidLogin("khiem@gmail.com", "123456");
		assertEquals("Valid Login Test", true, isValid);
	}
	
	@Test
	void inValidLogin() {
		Server s = new Server();
		boolean isValid = s.isValidLogin("khiem@gmail.com", "123456789");
		assertEquals("Invalid Login Test", true, isValid);
	}

}
